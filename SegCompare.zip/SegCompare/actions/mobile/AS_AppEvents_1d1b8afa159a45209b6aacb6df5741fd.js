function AS_AppEvents_1d1b8afa159a45209b6aacb6df5741fd(eventobject) {
    return appInitModules.call(this);
}
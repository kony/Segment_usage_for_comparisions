function AS_Image_a4b75ed8bf49455ebaa2daccc7bbbeb2(eventobject, x, y) {
    frmCompare.show();
}
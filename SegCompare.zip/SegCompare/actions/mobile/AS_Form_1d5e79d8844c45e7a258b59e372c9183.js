function AS_Form_1d5e79d8844c45e7a258b59e372c9183(eventobject) {
    return setWeatherInfo2seg.call(this);
}
function AS_ListBox_f435ea8f3a1b4c2bb8fd2c22551f36ae(eventobject) {
    return onListBox1Selection.call(this);
}
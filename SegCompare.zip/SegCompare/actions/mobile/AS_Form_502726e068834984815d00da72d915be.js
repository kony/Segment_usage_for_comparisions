function AS_Form_502726e068834984815d00da72d915be(eventobject) {
    return setWeatherInfo2seg.call(this);
}
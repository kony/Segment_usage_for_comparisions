function AS_ListBox_e4542570a30c425f8d89d302627be303(eventobject) {
    return onListBox2Selection.call(this);
}